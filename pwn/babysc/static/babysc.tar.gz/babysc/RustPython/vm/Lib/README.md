# Frozen Python modules

A collection of Python modules frozen into the VM at compile time.

See the comments in [`frozen.rs`](../src/frozen.rs) for explanations of the
different files and subdirectories in this directory.
