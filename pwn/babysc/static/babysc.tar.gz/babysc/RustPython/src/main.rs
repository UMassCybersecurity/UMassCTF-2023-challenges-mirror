pub fn main() -> std::process::ExitCode {
    rustpython::run(|_vm| {})
}
