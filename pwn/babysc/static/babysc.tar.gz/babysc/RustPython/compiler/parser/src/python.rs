#![allow(clippy::all)]
#![allow(unused)]
include!(concat!(env!("OUT_DIR"), "/python.rs"));
